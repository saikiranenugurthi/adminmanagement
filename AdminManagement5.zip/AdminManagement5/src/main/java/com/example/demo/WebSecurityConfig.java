package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
@Configuration
@EnableWebSecurity

public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	
	
//	@Autowired
//	private AuthenticationSuccessHandler successHandler;
	@Bean
	public UserDetailsService userDetailsService() {
		return new UserDetailServiceImpl();
	}
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		auth.authenticationProvider(authenticationProvider());}
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
////
//http.authorizeRequests().anyRequest().authenticated().and().formLogin().permitAll().and().logout().permitAll();
////		// URLs matching for access rights
////		http.authorizeRequests().antMatchers("/").permitAll()
////		.antMatchers("/login").permitAll()
////		.antMatchers("/home/**").hasAnyAuthority("REPORTING_USER", "ADMIN", "EMPLOYEE")
////		.anyRequest().authenticated()
////		.and()
////		// form login
////		.csrf().disable().formLogin()
////		.loginPage("/login")
////		.failureUrl("/login?error=true")
////		.defaultSuccessUrl("/home")
////		.usernameParameter("username")
////		.passwordParameter("password")
////		.and()
////		// logout
////		.logout()
////		.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
////		.logoutSuccessUrl("/").and()
////		.exceptionHandling()
////		.accessDeniedPage("/access-denied");
//	
//	
//	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider=new DaoAuthenticationProvider();
		authProvider.setPasswordEncoder(passwordEncoder());
		authProvider.setUserDetailsService(userDetailsService());
		return authProvider;
		
	}


	@Override
	protected void configure(HttpSecurity http) throws Exception {
//		http.authorizeRequests().anyRequest().authenticated().and().formLogin().permitAll().and().logout().permitAll();

////		.antMatchers("/").permitAll()
//		.antMatchers("/admin").hasAnyRole("ADMIN")
//		.antMatchers("/Employee").hasAnyRole("EMPLOYEE")
//		.antMatchers("/Repomanager").hasAnyRole("REPORTINGUSERr")
//		.anyRequest().authenticated()
//		.and()
//		.formLogin().successHandler(successHandler)
//		.and()
//		.logout().permitAll()
//		;
//		
//	}
		
		////sure something is showing **************************************
		http.authorizeRequests()
		.antMatchers("/").hasAnyAuthority("EMPLOYEE","REPORTINGUSER","ADMIN")
		.antMatchers("/admin").hasAnyAuthority("ADMIN")
		.antMatchers("/Employee/**").hasAuthority( "EMPLOYEE")
		.antMatchers("/Repomanager/**").hasAuthority("REPORTINGUSER")
		.anyRequest().authenticated()
		.and()
		.formLogin().permitAll()
		.and()
	.logout().permitAll()
//		.and()
//	.exceptionHandling().accessDeniedPage("/403")
	;

	}}
