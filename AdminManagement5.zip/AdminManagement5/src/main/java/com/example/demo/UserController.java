package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@CrossOrigin(origins="http://locahost:4200")
@RestController
public class UserController {
	@Autowired
	private UserRepository userRepository;
	
	
	@RequestMapping(value={"/admin"},method = RequestMethod.GET)
	public ModelAndView admin() {
		ModelAndView  modelAndView=new ModelAndView();
		modelAndView.setViewName("admin");
		return modelAndView;
	}
	
//	@RequestMapping(value = { "/login" }, method = RequestMethod.GET)
//	public ModelAndView login() {
//		ModelAndView modelAndView = new ModelAndView();
//		modelAndView.setViewName("login"); // resources/template/login.html
//		return modelAndView;
//	}
	@RequestMapping(value= {"/Employee"},method=RequestMethod.GET)
	public ModelAndView employee() {
		ModelAndView mav1=new ModelAndView();
		mav1.setViewName("employee");
	return mav1;
	}
	@RequestMapping(value= {"/Repomanager"},method=RequestMethod.GET)
	public ModelAndView ReportingManager() {
		ModelAndView mav2=new ModelAndView();
		mav2.setViewName("Repomanager");
		return mav2;
	}
	

//	@PostMapping("/admin")
//	public String login(@RequestBody User user) {
//		userRepository.save(user);
//		return "hello "+"admin is working"+user.getUsername();
//	}
 
//    @PostMapping("/users")
//    void addUser(@RequestBody User user) {
//        userRepository.save(user);
//    }

}
